<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'vitalya' );

/** MySQL database username */
define( 'DB_USER', 'vitalya' );

/** MySQL database password */
define( 'DB_PASSWORD', 'pDzdR10IyEtKIA7Q' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ';9piE9C=0hqdvuj+$,B ;q`ZgE*82^8`N>b80eseDh*#yhhY9UforG]S1e +YZ9>' );
define( 'SECURE_AUTH_KEY',  '6z#uoRdI~+`z3+%0vh,=r/2.~-%@>n7:4XiC5V2%6Ab)&a=w3[KWdQes3m#=404T' );
define( 'LOGGED_IN_KEY',    'X]*|b#16Cfzq|P;0&U%Rpx;JFfI>~|>/h/~7/mKo,9~8&)lQKpy{_ 1A.a+C0 p&' );
define( 'NONCE_KEY',        '^y2GEBz#tR8aHr_r|M-h%sn+LH7v&0>t-4m#n25S I$:F]taeF*]}ACz*R=*$$5_' );
define( 'AUTH_SALT',        '_{k2_Po#;KyAR_;]Dsr#*Zz&U6eCU1UA6w a4V8F/ryNl-[QdThIVry[0(g;mx?u' );
define( 'SECURE_AUTH_SALT', 'o_Gt<tr|HaJkCzQ9Z{|l/|PWMSt0v=P]}#t:0mr{nO@_-g*XqZvL~r)r7v^AYE6w' );
define( 'LOGGED_IN_SALT',   'xl9DXmFZ?a%^`!7H35X+(qaRNeuV}#|8`:~kWzIRpSU^7vagF{(xc%e)r!l|Xes/' );
define( 'NONCE_SALT',       ' _@Zn! tuNjqT#fn-:j8HEA2,+:r4`PO;3q}OE/1&$.BL7J^H+l=fPR4FAYX+<w(' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
